#### version

* 20250829
   Remap the I2C address of the EEPROM

